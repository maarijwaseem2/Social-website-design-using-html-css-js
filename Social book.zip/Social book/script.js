var settingmenu=document.querySelector(".setting-menu");
var darkbtn=document.getElementById("dark-btn");
function settingMenuToggle(){
    settingmenu.classList.toggle("setting-menu-heigth");
}
darkbtn.onclick = function( ){
    darkbtn.classList.toggle("dark-btn-on");
    document.body.classList.toggle("dark-theme");
    if(localStorage.getItem("theme")=="ligth"){
        localStorage.setItem("theme","dark");
    }
    else{
        localStorage.setItem("theme","ligth");
    }
}

if(localStorage.getItem("theme")=="ligth"){
    darkbtn.classList.remove("dark-btn-on");
    document.body.classList.remove("dark-theme");
}
else if(localStorage.getItem("theme")=="ligth"){
    darkbtn.classList.add("dark-btn-on");
    document.body.classList.add("dark-theme");
}
else{
    localStorage.setItem("theme","ligth");
}


